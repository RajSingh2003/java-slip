import java.util.*;
import java.io.*;
class p1
{
	public static void main(String[] args)
	{
		int i,j,x,f;
		Scanner s=new Scanner(System.in);
        //System.out.println("Enter no");
		//n=s.nextInt();
		int n=10;
		int []a=new int[n];
		for(i=0;i<n;i++)
		{
			a[i]=s.nextInt();
		}
        for(i=0;i<n;i++)
		{
			x=a[i];
			f=0;
			for(j=2;j<x;j++)
			{
				if(x%j==0)
					f=1;
				   break;
			}
			if(f==2)
				System.out.println(x+" ");
		}			
	}
}