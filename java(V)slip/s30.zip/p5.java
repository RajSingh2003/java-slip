import java.util.*;
import java.io.*;
interface cub
{
	int fun(int x);
}
class p5
{
	public static void main(String[] args)
	{
		int i,n;
		Scanner s=new Scanner(System.in);
        System.out.println("Enter no");
		n=s.nextInt();
		cub a=(int k)->k*k*k;
		int ans=a.fun(n);
		System.out.println(" no"+ans);
		
		
	}
}