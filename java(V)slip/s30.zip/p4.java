import java.util.*;
import java.io.*;

class p4
{
	public static void main(String[] args)throws IOException
	{
		int i,n;
		//Scanner s=new Scanner(System.in);
		FileReader f=new FileReader("sa.txt");
		Scanner s=new Scanner(f);
		String c1,c2;
		while(s.hasNext())
		{
			StringBuilder c =new StringBuilder();
			c1=s.next();
			c2=c1.toUpperCase();
			c.append(c2);
			c.reverse();
			System.out.println(c);
		}
		f.close();
        	
	}
}