import java.util.*;
import java.io.*;
import java.util.Arrays;
class p3
{
	public static void main(String[] args)
	{
		int i,n;
		Scanner s=new Scanner(System.in);
        System.out.println("Enter no");
		n=s.nextInt();
		String []a=new String[n];
		s.nextLine();
		System.out.println("Enter");
		for(i=0;i<n;i++)
		{
			a[i]=s.next();
		}
		Arrays.sort(a);
        for(i=0;i<n;i++)
		{
				System.out.println(a[i]);
		}			
	}
}