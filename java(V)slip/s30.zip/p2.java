import java.util.*;
import java.io.*;
class p2
{
	public static void main(String[] args)
	{
		int i,j,x;
		String f,l;
/*Scanner s=new Scanner(System.in);
        System.out.println("Enter f nmae");
		f=s.next();
		System.out.println("Enter l nmae");
		l=s.next();*/
		f=args[0];
		l=args[1];
		int h=Integer.parseInt(args[2]);
		int w=Integer.parseInt(args[3]);
		
		float b=w/(h*h);
		
		System.out.println(" f nmae"+f);
		System.out.println(" l nmae"+l);
		System.out.println("bmi %f"+b);
		
		
	}
}