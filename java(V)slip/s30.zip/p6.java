import java.util.*;
import java.io.*;
import java.io.File;
class p6
{
	public static void main(String[] args)throws IOException
	{
		int i,n;
		String f1,f2;
		Scanner s=new Scanner(System.in);
        System.out.println("Enter f1");
		f1=s.next();
		System.out.println("Enter f2");
		f2=s.next();
		FileReader fin=new FileReader(f1);
		FileWriter fout=new FileWriter(f2,true);
		int c;
		while((c=fin.read())!=-1)
		{
			fout.write(c);
		}
		 System.out.println("Enter f1");
		
		fin.close();
		fout.close();
	}
}